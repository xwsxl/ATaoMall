//
//  JFAppDelegate.m
//  JPushDemo
//
//  Created by iJeff on 15/5/25.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "JFAppDelegate.h"

#import "APService.h"

@implementation JFAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
#pragma  mark - 注册JPush推送
    //通过极光 注册远程推送
    [APService registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert) categories:nil];
    
    //初始化
    [APService setupWithOption:launchOptions];
    
    
#pragma  mark - JPush通知事件
    //监听 建立连接
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkDidSetup:) name:kJPFNetworkDidSetupNotification object:nil];
    
    //监听 关闭连接
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkDidClose:) name:kJPFNetworkDidCloseNotification object:nil];
    
    //监听 注册成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkDidRegister:) name:kJPFNetworkDidRegisterNotification object:nil];
    
    //监听 登陆成功
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkDidLogin:) name:kJPFNetworkDidLoginNotification object:nil];
    
    //监听 接收到信息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(networkDidReceiveMessage:) name:kJPFNetworkDidReceiveMessageNotification object:nil];

    //监听 错误信息
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(ServiceError:) name:kJPFServiceErrorNotification object:nil];
    
    
    return YES;
}


#pragma  mark - 远程推送

#pragma  mark -- APNs推送
//在APNs上注册成功
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSLog(@"注册DeviceToken成功：%@", deviceToken);
    
    // 向服务器上报Device Token
    [APService registerDeviceToken:deviceToken];
}
//注册失败
-(void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
    NSLog(@"注册失败：%@", error);
}


//接收到远程消息
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"接收到远程推送：%@", userInfo);
    
    // 处理收到的APNS消息，向服务器上报收到APNS消息
    [APService handleRemoteNotification:userInfo];
}


#pragma  mark -- JPush推送
// 已建立连接
-(void)networkDidSetup:(NSNotification *)notification
{
    NSLog(@"已与JPush建立连接");
}

// 已关闭连接
-(void)networkDidClose:(NSNotification *)notification
{
    NSLog(@"已与JPush关闭连接");
}

// 已注册成功
-(void)networkDidRegister:(NSNotification *)notification
{
    NSLog(@"已在JPush上注册成功");
}

// 已登陆成功
-(void)networkDidLogin:(NSNotification *)notification
{
    NSLog(@"已在JPush上登陆成功");
}

// 已接收到数据
-(void)networkDidReceiveMessage:(NSNotification *)notification
{
    NSLog(@"已接收到JPush发送过来的数据：%@", notification.userInfo);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"接收到消息" message:notification.userInfo[@"content"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    
}

// 已出现错误
-(void)ServiceError:(NSNotification *)notification
{
    NSLog(@"出现错误");
}







#pragma  mark - Application 代理方法
							
- (void)applicationWillResignActive:(UIApplication *)application
{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    application.applicationIconBadgeNumber = 0;
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
}

- (void)applicationWillTerminate:(UIApplication *)application
{
}

@end
